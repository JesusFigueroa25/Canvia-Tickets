from datetime import date, timedelta

import pandas as pd
from sqlalchemy import (Integer, case, cast, delete, func,insert,select,)
from sqlalchemy.orm import Session
from app.models.requirement_consolidated_model import (RequirementConsolidated,stg_requirement_consolidated_table,)

# UTILIDAD
def _dataframe_a_registros(df: pd.DataFrame):
    df_sql = df.copy()
    df_sql = df_sql.astype(object).where(pd.notna(df_sql), None)
    return df_sql.to_dict(orient="records")

# STAGING
def limpiar_staging(db: Session):
    db.execute(delete(stg_requirement_consolidated_table))

def cargar_staging(db: Session,df: pd.DataFrame):
    columnas_staging = [
        columna.name
        for columna
        in stg_requirement_consolidated_table.columns
    ]

    faltantes = [
        columna
        for columna in columnas_staging
        if columna not in df.columns
    ]

    if faltantes:
        raise ValueError(f"Faltan columnas para staging: {faltantes}")

    df_staging = df[columnas_staging].copy()
    registros = _dataframe_a_registros(df_staging)

    if registros:
        tamano_lote = 500

        for inicio in range(0,len(registros),tamano_lote):
            lote = registros[inicio:inicio + tamano_lote]
            db.execute(insert(stg_requirement_consolidated_table),lote)

    return len(registros)

# CONSULTAS
def obtener_staging(db: Session):
    consulta = select(stg_requirement_consolidated_table)
    return pd.read_sql(consulta,db.connection())

def obtener_oficial(db: Session):
    columnas = [
        RequirementConsolidated.__table__.c[columna.name]
        for columna in stg_requirement_consolidated_table.columns
    ]
    consulta = (
        select(*columnas)
        .select_from(
            RequirementConsolidated.__table__.join(
                stg_requirement_consolidated_table,
                RequirementConsolidated.Ticket_ID == stg_requirement_consolidated_table.c.Ticket_ID
            )
        )
    )
    return pd.read_sql(consulta,db.connection())

# INSERT
def insertar_nuevos(db: Session,df: pd.DataFrame):
    if df.empty:
        return 0
    registros = _dataframe_a_registros(df)
    db.execute(insert(RequirementConsolidated.__table__), registros)
    return len(registros)

# UPDATE
def actualizar_modificados(db: Session,df: pd.DataFrame):
    if df.empty:
        return 0
    registros = _dataframe_a_registros(df)
    db.bulk_update_mappings(RequirementConsolidated, registros)
    return len(registros)

def contar_total(db: Session):
    return db.query(func.count()).select_from(RequirementConsolidated).scalar() or 0

#-------------------------------------------------------------

#Metodos globales

# Aplicar filtros del dashboard
def aplicar_filtros_dashboard(
    consulta,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    # Fecha desde
    if desde:
        consulta = consulta.where(
            RequirementConsolidated.Fecha_Apertura >= desde
        )

    # Fecha hasta
    if hasta:
        consulta = consulta.where(
            RequirementConsolidated.Fecha_Apertura <
            hasta + timedelta(days=1)
        )

    # Prioridad
    if prioridad:
        consulta = consulta.where(
            RequirementConsolidated.Prioridad == prioridad
        )

    # Motivo de estado
    if motivo_estado:
        consulta = consulta.where(
            RequirementConsolidated.Motivo_Estado == motivo_estado
        )

    # Motivo de resolución
    if motivo_resolucion:
        consulta = consulta.where(
            RequirementConsolidated.Motivo_Resolucion ==
            motivo_resolucion
        )

    # Grupo resolutor
    if grupo_resolutor:
        consulta = consulta.where(
            func.trim(
                RequirementConsolidated.Grupo_Resolutor
            ) == grupo_resolutor
        )

    # Proyecto
    if proyecto is not None and proyecto.strip():
        proyecto_col = func.coalesce(
            func.nullif(
                func.trim(RequirementConsolidated.Proyecto),
                ""
            ),
            "Sin especificar"
        )

        consulta = consulta.where(
            proyecto_col == proyecto.strip()
        )

    # Filtro dinámico por mes
    if periodo:
        inicio_mes, fin_mes = obtener_rango_periodo(periodo)

        consulta = consulta.where(
            RequirementConsolidated.Fecha_Apertura >= inicio_mes,
            RequirementConsolidated.Fecha_Apertura < fin_mes
        )

    # Filtro dinámico por varios tipos
    tipos = normalizar_tipos_requerimiento(
        tipo_requerimiento
    )

    if tipos:
        consulta = consulta.where(
            func.lower(
                normalizar_tipo_requerimiento()
            ).in_(tipos)
        )

    return consulta

    

# Normalizar lista de tipos seleccionados
def normalizar_tipos_requerimiento(tipos_requerimiento):
    if tipos_requerimiento is None:
        return []

    if isinstance(tipos_requerimiento, str):
        tipos_requerimiento = [tipos_requerimiento]

    resultado = []
    vistos = set()

    for valor in tipos_requerimiento:
        if not isinstance(valor, str):
            continue

        limpio = valor.strip()

        if not limpio:
            continue

        clave = limpio.lower()

        if clave not in vistos:
            resultado.append(clave)
            vistos.add(clave)

    return resultado


# Normalizar tipo de requerimiento de SQL Server
def normalizar_tipo_requerimiento():
    return func.coalesce(
        func.nullif(
            func.trim(
                RequirementConsolidated.Categorizacion_Nivel_3
            ),
            ""
        ),
        "Sin especificar"
    )

# Obtener inicio y fin del mes seleccionado
def obtener_rango_periodo(periodo: str):
    inicio = date.fromisoformat(f"{periodo}-01")

    if inicio.month == 12:
        fin = date(inicio.year + 1, 1, 1)
    else:
        fin = date(inicio.year, inicio.month + 1, 1)

    return inicio, fin
    
    

def obtener_kpis(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    proyecto_col = func.nullif(
        func.trim(RequirementConsolidated.Proyecto),
        ""
    )

    consulta = (
        select(
            func.count().label("total_tickets"),

            func.count(
                func.distinct(proyecto_col)
            ).label("total_proyectos"),

            func.sum(
                case(
                    (
                        RequirementConsolidated.Prioridad.in_(
                            ["1-Critical"]
                        ),
                        1
                    ),
                    else_=0
                )
            ).label("alta_criticidad")
        )
        .select_from(RequirementConsolidated)
    )

    consulta = aplicar_filtros_dashboard(
        consulta,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    return db.execute(consulta).mappings().one()


def obtener_opciones_filtros(db: Session):
    consulta_fechas = select(
        func.min(RequirementConsolidated.Fecha_Apertura).label("fecha_min"),
        func.max(RequirementConsolidated.Fecha_Apertura).label("fecha_max"),
    )

    fechas = db.execute(consulta_fechas).mappings().one()

    def obtener_opciones(columna):
        valor = func.trim(columna)

        consulta = (
            select(valor)
            .where(columna.isnot(None),valor != "")
            .distinct()
            .order_by(valor)
        )

        return db.execute(consulta).scalars().all()

    return {
        "fecha_min": fechas["fecha_min"],
        "fecha_max": fechas["fecha_max"],
        "prioridades": obtener_opciones(RequirementConsolidated.Prioridad),
        "motivos_estado": obtener_opciones(RequirementConsolidated.Motivo_Estado),
        "motivos_resolucion": obtener_opciones(RequirementConsolidated.Motivo_Resolucion),
        "grupos_resolutores": obtener_opciones(RequirementConsolidated.Grupo_Resolutor),
        "proyectos": obtener_opciones(RequirementConsolidated.Proyecto),
    }    
    
#-------------------------------------------------------------

#Volumen Mensual de Requerimientos

# Volumen Mensual de Requerimientos
def obtener_volumen_mensual(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    anio = func.year(
        RequirementConsolidated.Fecha_Apertura
    )

    mes = func.month(
        RequirementConsolidated.Fecha_Apertura
    )

    consulta = (
        select(
            anio.label("anio"),
            mes.label("mes"),
            func.count().label("tickets")
        )
        .select_from(RequirementConsolidated)
        .where(
            RequirementConsolidated.Fecha_Apertura.isnot(None)
        )
        .group_by(anio, mes)
        .order_by(anio, mes)
    )

    consulta = aplicar_filtros_dashboard(
        consulta,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    return db.execute(consulta).all()



#Explorador por Proyectos

# Explorador por Proyectos
def obtener_proyectos(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    proyecto_col = func.coalesce(
        func.nullif(
            func.trim(RequirementConsolidated.Proyecto),
            ""
        ),
        "Sin especificar"
    )

    consulta_base = (
        select(
            proyecto_col.label("proyecto")
        )
        .select_from(RequirementConsolidated)
    )

    consulta_base = aplicar_filtros_dashboard(
        consulta_base,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    datos = consulta_base.subquery()

    consulta = (
        select(
            datos.c.proyecto,
            func.count().label("cantidad")
        )
        .select_from(datos)
        .group_by(datos.c.proyecto)
        .order_by(
            func.count().desc(),
            datos.c.proyecto.asc()
        )
    )

    return db.execute(consulta).mappings().all()

 

#Distribución por Tipo de Requerimiento
def obtener_tipos(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    limite: int = 10,
    periodo=None,
    tipo_requerimiento=None
):
    tipo = normalizar_tipo_requerimiento()

    consulta_base = (
        select(
            tipo.label("tipo")
        )
        .select_from(RequirementConsolidated)
    )

    consulta_base = aplicar_filtros_dashboard(
        consulta_base,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    datos = consulta_base.subquery()

    tipo_normalizado = func.lower(
        datos.c.tipo
    )

    consulta = (
        select(
            func.min(
                datos.c.tipo
            ).label("tipo_requerimiento"),

            func.count().label("cantidad")
        )
        .select_from(datos)
        .group_by(tipo_normalizado)
        .order_by(
            func.count().desc(),
            func.min(datos.c.tipo).asc()
        )
        .limit(limite)
    )

    return db.execute(consulta).mappings().all()


#Distribución por Prioridad

# Distribución por Prioridad
def obtener_prioridades(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    prioridad_col = func.coalesce(
        func.nullif(
            func.trim(RequirementConsolidated.Prioridad),
            ""
        ),
        "Sin especificar"
    )

    consulta_base = (
        select(
            prioridad_col.label("prioridad")
        )
        .select_from(RequirementConsolidated)
    )

    consulta_base = aplicar_filtros_dashboard(
        consulta_base,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    datos = consulta_base.subquery()

    consulta = (
        select(
            datos.c.prioridad,
            func.count().label("cantidad")
        )
        .select_from(datos)
        .group_by(datos.c.prioridad)
        .order_by(
            func.count().desc(),
            datos.c.prioridad.asc()
        )
    )

    return db.execute(consulta).mappings().all()


#Top 10: Tickets por Proyecto y Mes

# Top 10: Tickets por Proyecto y Mes
def obtener_top_proyectos_mensual(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    anio = func.year(
        RequirementConsolidated.Fecha_Apertura
    )

    mes = func.month(
        RequirementConsolidated.Fecha_Apertura
    )

    proyecto_col = func.coalesce(
        func.nullif(
            func.trim(RequirementConsolidated.Proyecto),
            ""
        ),
        "Sin especificar"
    )

    consulta_base = (
        select(
            proyecto_col.label("proyecto"),
            anio.label("anio"),
            mes.label("mes")
        )
        .select_from(RequirementConsolidated)
        .where(
            RequirementConsolidated.Fecha_Apertura.isnot(None)
        )
    )

    consulta_base = aplicar_filtros_dashboard(
        consulta_base,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    datos = consulta_base.subquery()

    consulta = (
        select(
            datos.c.proyecto,
            datos.c.anio,
            datos.c.mes,
            func.count().label("tickets")
        )
        .select_from(datos)
        .group_by(
            datos.c.proyecto,
            datos.c.anio,
            datos.c.mes
        )
        .order_by(
            datos.c.anio,
            datos.c.mes,
            datos.c.proyecto
        )
    )

    return db.execute(consulta).mappings().all()


#N.º de Requerimientos por Prioridad

# N.º de Requerimientos por Prioridad
def obtener_prioridad_mensual(
    db: Session,
    desde=None,
    hasta=None,
    prioridad=None,
    motivo_estado=None,
    motivo_resolucion=None,
    grupo_resolutor=None,
    proyecto=None,
    periodo=None,
    tipo_requerimiento=None
):
    anio = func.year(
        RequirementConsolidated.Fecha_Apertura
    )

    mes = func.month(
        RequirementConsolidated.Fecha_Apertura
    )

    prioridad_col = func.coalesce(
        func.nullif(
            func.trim(RequirementConsolidated.Prioridad),
            ""
        ),
        "Sin especificar"
    )

    consulta_base = (
        select(
            anio.label("anio"),
            mes.label("mes"),
            prioridad_col.label("prioridad")
        )
        .select_from(RequirementConsolidated)
        .where(
            RequirementConsolidated.Fecha_Apertura.isnot(None)
        )
    )

    consulta_base = aplicar_filtros_dashboard(
        consulta_base,
        desde,
        hasta,
        prioridad,
        motivo_estado,
        motivo_resolucion,
        grupo_resolutor,
        proyecto,
        periodo=periodo,
        tipo_requerimiento=tipo_requerimiento
    )

    datos = consulta_base.subquery()

    consulta = (
        select(
            datos.c.anio,
            datos.c.mes,
            datos.c.prioridad,
            func.count().label("cantidad")
        )
        .select_from(datos)
        .group_by(
            datos.c.anio,
            datos.c.mes,
            datos.c.prioridad
        )
        .order_by(
            datos.c.anio,
            datos.c.mes
        )
    )

    return db.execute(consulta).mappings().all()
