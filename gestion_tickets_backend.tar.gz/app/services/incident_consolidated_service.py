from datetime import datetime
from sqlalchemy import func, select
from sqlalchemy.orm import Session
from app.database.sqlserver import verificar_conexion_sqlserver
from app.etl.incident_consolidated_etl import procesar_incident_consolidated
from app.etl.change_detector import detectar_cambios
from app.models.incident_consolidated_model import IncidentConsolidated
from app.repositories import (incident_consolidated_repository,import_run_repository,)

def importar(db: Session,archivo,nombre_archivo=None):
    fecha_inicio = datetime.now()
    
    # 1. Validar conexión a SQL Server
    try:
        verificar_conexion_sqlserver(db)
    except Exception:
        db.rollback()
        raise ConnectionError(
            "No hay conexión con SQL Server. Verifique que esté conectado a la red de Canvia."
        ) from error

    try:
        # 2. Crear auditoría
        import_run = import_run_repository.crear(
            db=db,
            tipo="incident_consolidated",
            nombre_archivo=nombre_archivo,
            fecha_inicio=fecha_inicio,
            sqlite_status="NO_APLICA",
            sqlserver_status="PROCESSING"
        )

        # 3. Ejecutar ETL
        archivo.seek(0)
        df = procesar_incident_consolidated(archivo)
        filas_procesadas = len(df)

        # 4. STAGING - SQL SERVER
        incident_consolidated_repository.limpiar_staging(db)
        filas_staging = incident_consolidated_repository.cargar_staging(db,df)
        db.flush()

        # 5. COMPARACIÓN - SQL SERVER
        df_staging = incident_consolidated_repository.obtener_staging(db)
        df_oficial = incident_consolidated_repository.obtener_oficial(db)
        resultado = detectar_cambios(df_staging, df_oficial)

        df_new = resultado["NEW"]
        df_changed = resultado["CHANGED"]
        df_same = resultado["SAME"]

        #  6. INSERT - SQL SERVER
        nuevos = incident_consolidated_repository.insertar_nuevos(db, df_new)
        
        # 7. UPDATE - SQL SERVER
        modificados = incident_consolidated_repository.actualizar_modificados(db, df_changed)
        sin_cambios = len(df_same)

        # 8. COMPLETAR AUDITORÍA
        fecha_fin = datetime.now()

        import_run_repository.completar(
            db=db,
            import_run=import_run,
            fecha_fin=fecha_fin,
            filas_excel=filas_procesadas,
            filas_aceptadas=filas_staging,
            filas_rechazadas=max(filas_procesadas - filas_staging,0),
            nuevos=nuevos,
            modificados=modificados,
            sin_cambios=sin_cambios,
            sqlite_status="NO_APLICA",
            sqlserver_status="SUCCESS"
        )
        
        # 9. CONFIRMAR TRANSACCIÓN
        db.commit()

    except Exception as error:
        
        db.rollback()

        try:
            import_run_error = import_run_repository.crear(
                db=db,
                tipo="incident_consolidated",
                nombre_archivo=nombre_archivo,
                fecha_inicio=fecha_inicio,
                sqlite_status="NO_APLICA",
                sqlserver_status="ERROR"
            )

            import_run_repository.marcar_error(
                db=db,
                import_run=import_run_error,
                fecha_fin=datetime.now(),
                error=error,
                sqlite_status="NO_APLICA",
                sqlserver_status="ERROR"
            )

            db.commit()

        except Exception:
            db.rollback()

        raise

    return {
        "tipo": "incident_consolidated",
        "tabla_staging": "stg_incident_consolidated",
        "tabla_destino": "incident_consolidated",
        "filas_procesadas": filas_procesadas,
        "filas_staging": filas_staging,
        "nuevos": nuevos,
        "modificados": modificados,
        "sin_cambios": sin_cambios,
        "mensaje": "Archivo procesado y cambios clasificados"
    }
    

def obtener_opciones_filtros(db: Session):
    return incident_consolidated_repository.obtener_opciones_filtros(db)

    
def obtener_kpis(
    db: Session,desde=None,hasta=None,prioridad=None, 
    motivo_estado=None,motivo_resolucion=None, 
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_kpis(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    total_tickets = resultado["total_tickets"] or 0
    total_proyectos = resultado["total_proyectos"] or 0
    alta_criticidad = resultado["alta_criticidad"] or 0

    porcentaje = round(alta_criticidad * 100 / total_tickets,2) if total_tickets else 0.0

    return {
        "total_tickets": total_tickets,
        "total_proyectos": total_proyectos,
        "alta_criticidad": alta_criticidad,
        "porcentaje_alta_criticidad": porcentaje,
    }
    
def obtener_volumen_mensual(
    db: Session, 
    desde=None, 
    hasta=None, 
    prioridad=None, 
    motivo_estado=None, 
    motivo_resolucion=None, 
    grupo_resolutor=None, 
    proyecto=None,
    nombre_resolutor=None,
    descripcion=None,
    periodo=None,
    tipo_incidente=None,
    detalle_id=None
):
    resultados = incident_consolidated_repository.obtener_volumen_mensual(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    meses = {
        1:"ENE",2:"FEB",3:"MAR",4:"ABR",
        5:"MAY",6:"JUN",7:"JUL",8:"AGO",
        9:"SEP",10:"OCT",11:"NOV",12:"DIC",
    }

    return [
        {
            "anio": row.anio,
            "mes": row.mes,
            "periodo": f"{meses[row.mes]}-{str(row.anio)[-2:]}",
            "tickets": row.tickets,
        }
        for row in resultados
    ]
    
def obtener_proyectos(
    db: Session,desde=None,hasta=None,prioridad=None, 
    motivo_estado=None,motivo_resolucion=None, 
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultados = incident_consolidated_repository.obtener_proyectos(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    return [
        {
            "proyecto": row["proyecto"],
            "cantidad": row["cantidad"],
        }
        for row in resultados
    ]    
     
def obtener_tipos(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None, 
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    limite: int = 10,periodo=None,
    tipo_incidente=None,detalle_id=None
):    
    resultados = incident_consolidated_repository.obtener_tipos(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,limite,periodo,
        tipo_incidente,detalle_id
    )

    return [
        {
            "tipo_incidente": row["tipo_incidente"],
            "cantidad": row["cantidad"],
        }
        for row in resultados
    ]     
        
def obtener_prioridades(
    db: Session,desde=None,hasta=None,prioridad=None, 
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):    
    resultados = incident_consolidated_repository.obtener_prioridades(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    return [
        {
            "prioridad": row["prioridad"],
            "cantidad": row["cantidad"],
        }
        for row in resultados
    ]
    
def obtener_top_proyectos(
    db: Session,desde=None,hasta=None,prioridad=None, 
    motivo_estado=None,motivo_resolucion=None, 
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultados = incident_consolidated_repository.obtener_top_proyectos_mensual(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    if not resultados:
        return {"periodos":[],"proyectos":[]}

    meses = {
        1:"ENE",2:"FEB",3:"MAR",4:"ABR",
        5:"MAY",6:"JUN",7:"JUL",8:"AGO",
        9:"SEP",10:"OCT",11:"NOV",12:"DIC",
    }

    def indice(anio,mes):
        return anio * 12 + mes - 1

    indices = [indice(row["anio"],row["mes"]) for row in resultados]
    fin = indice(hasta.year,hasta.month) if hasta else max(indices)
    inicio = indice(desde.year,desde.month) if desde else (min(indices) if hasta else fin - 3)

    if inicio > fin:
        return {"periodos":[],"proyectos":[]}

    periodos = []
    for valor in range(inicio,fin + 1):
        anio,mes_indice = divmod(valor,12)
        mes = mes_indice + 1

        periodos.append({
            "anio": anio,
            "mes": mes,
            "periodo": f"{meses[mes]}-{str(anio)[-2:]}",
        })

    proyectos = {}

    for row in resultados:
        clave_mes = indice(row["anio"],row["mes"])
        if not inicio <= clave_mes <= fin:
            continue
        proyecto = row["proyecto"]
        if proyecto not in proyectos:
            proyectos[proyecto] = {"total_tickets":0,"conteos":{}}
        proyectos[proyecto]["total_tickets"] += row["tickets"]
        proyectos[proyecto]["conteos"][clave_mes] = row["tickets"]

    ranking = sorted(proyectos.items(),key=lambda item:(-item[1]["total_tickets"],item[0]))[:10]

    return {
        "periodos": periodos,
        "proyectos": [
            {
                "proyecto": proyecto,
                "total_tickets": datos["total_tickets"],
                "mensual": [
                    {
                        "periodo": periodo["periodo"],
                        "tickets": datos["conteos"].get(indice(periodo["anio"],periodo["mes"]),0),
                    }
                    for periodo in periodos
                ],
            }
            for proyecto,datos in ranking
        ],
    }
    
def obtener_prioridad_mensual(
    db: Session, desde=None,hasta=None,prioridad=None, 
    motivo_estado=None,motivo_resolucion=None, 
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultados = incident_consolidated_repository.obtener_prioridad_mensual(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo, 
        tipo_incidente,detalle_id
    )

    meses = {
        1:"ENE",2:"FEB",3:"MAR",4:"ABR",
        5:"MAY",6:"JUN",7:"JUL",8:"AGO",
        9:"SEP",10:"OCT",11:"NOV",12:"DIC",
    }

    prioridades = ["1-Critical","2-High","3-Medium","4-Low"]
    resumen = {}

    for row in resultados:
        if row["anio"] is None or row["mes"] is None:
            continue
        clave = (row["anio"],row["mes"])
        if clave not in resumen:
            resumen[clave] = {
                "anio": row["anio"],
                "mes": row["mes"],
                "periodo": f"{meses[row['mes']]}-{str(row['anio'])[-2:]}",
                "total_tickets": 0,
                "conteos": {},
            }
        cantidad = row["cantidad"] or 0
        categoria = row["prioridad"]
        resumen[clave]["total_tickets"] += cantidad
        resumen[clave]["conteos"][categoria] = resumen[clave]["conteos"].get(categoria,0) + cantidad

    respuesta = []

    for clave in sorted(resumen):
        item = resumen[clave]
        total = item["total_tickets"]
        conteos = item["conteos"]
        categorias = prioridades + sorted(p for p in conteos if p not in prioridades)
        respuesta.append({
            "anio": item["anio"],
            "mes": item["mes"],
            "periodo": item["periodo"],
            "total_tickets": total,
            "prioridades": [
                {
                    "prioridad": p,
                    "cantidad": conteos.get(p,0),
                    "porcentaje": round(conteos.get(p,0) * 100 / total,2) if total else 0.0,
                }
                for p in categorias
            ],
        })

    return respuesta        

def obtener_rendimiento_resolutores(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    pagina=1,tamano=20,periodo=None,
    tipo_incidente=None,detalle_id=None
):
    resultados = incident_consolidated_repository.obtener_rendimiento_resolutores(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,
        periodo=periodo,
        tipo_incidente=tipo_incidente,
        detalle_id=detalle_id
    )

    meses = {
        1:"ENE",2:"FEB",3:"MAR",4:"ABR",
        5:"MAY",6:"JUN",7:"JUL",8:"AGO",
        9:"SEP",10:"OCT",11:"NOV",12:"DIC"
    }

    claves_meses = sorted({(r["anio"],r["mes"]) for r in resultados})

    periodos = [
        {
            "anio": anio,
            "mes": mes,
            "periodo": f"{meses[mes]}-{str(anio)[-2:]}"
        }
        for anio,mes in claves_meses
    ]

    resumen = {}
    totales_meses = {clave:0 for clave in claves_meses}

    for row in resultados:
        nombre = row["nombre_resolutor"]
        clave = (row["anio"],row["mes"])
        cantidad = row["tickets"]

        if nombre not in resumen:
            resumen[nombre] = {"total_tickets":0,"mensual":{}}

        resumen[nombre]["total_tickets"] += cantidad
        resumen[nombre]["mensual"][clave] = cantidad
        totales_meses[clave] += cantidad

    ranking = sorted(
        resumen.items(),
        key=lambda item:(-item[1]["total_tickets"],item[0])
    )

    total_resolutores = len(ranking)
    total_paginas = (total_resolutores + tamano - 1) // tamano
    inicio = (pagina - 1) * tamano
    ranking_paginado = ranking[inicio:inicio + tamano]

    return {
        "periodos": periodos,
        "resolutores": [
            {
                "nombre_resolutor": nombre,
                "total_tickets": datos["total_tickets"],
                "mensual": [
                    {
                        "periodo": periodo["periodo"],
                        "tickets": datos["mensual"].get((periodo["anio"],periodo["mes"]),0)
                    }
                    for periodo in periodos
                ]
            }
            for nombre,datos in ranking_paginado
        ],
        "totales_mensuales": [
            {
                "periodo": periodo["periodo"],
                "tickets": totales_meses[(periodo["anio"],periodo["mes"])]
            }
            for periodo in periodos
        ],
        "total_general": sum(totales_meses.values()),
        "total_resolutores": total_resolutores,
        "pagina": pagina,
        "tamano": tamano,
        "total_paginas": total_paginas
    }
    
    
def obtener_explorador_descripciones(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    pagina=1,tamano=10,buscar=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_explorador_descripciones(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,pagina,tamano,buscar,periodo,
        tipo_incidente,detalle_id
    )

    volumen = obtener_volumen_mensual(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    periodos = [
        {
            "anio": row["anio"],
            "mes": row["mes"],
            "periodo": row["periodo"]
        }
        for row in volumen
    ]

    conteos = {
        (row["descripcion"],row["anio"],row["mes"]): row["tickets"]
        for row in resultado["mensual"]
    }

    descripciones = [
        {
            "descripcion": row["descripcion"],
            "total_tickets": row["total_tickets"],
            "mensual": [
                {
                    "periodo": periodo["periodo"],
                    "tickets": conteos.get((row["descripcion"], periodo["anio"], periodo["mes"]),0)
                }
                for periodo in periodos
            ]
        }
        for row in resultado["descripciones"]
    ]

    total_descripciones = resultado["total_descripciones"]

    return {
        "periodos": periodos,
        "descripciones": descripciones,
        "totales_mensuales": [
            {
                "periodo": row["periodo"],
                "tickets": row["tickets"]
            }
            for row in volumen
        ],
        "total_general": sum(row["tickets"] for row in volumen),
        "total_descripciones": total_descripciones,
        "pagina": pagina,
        "tamano": tamano,
        "total_paginas": (total_descripciones + tamano - 1) // tamano
    }
    
    
def obtener_detalle_eventos_tecnicos(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    pagina=1,tamano=10,buscar=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_detalle_eventos_tecnicos(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,pagina,tamano,buscar,periodo,
        tipo_incidente,detalle_id
    )

    total_detalles = resultado["total_detalles"]

    return {
        "detalles": [
            {
                "detalle_id": row["detalle_id"],
                "detalle": row["detalle"],
                "total": row["total"]
            }
            for row in resultado["detalles"]
        ],
        "total_general": resultado["total_general"],
        "total_detalles": total_detalles,
        "pagina": pagina,
        "tamano": tamano,
        "total_paginas": (total_detalles + tamano - 1) // tamano
    }
    
    
def obtener_incidentes_porcentajes(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,limite=20,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_incidentes_porcentajes(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,limite,periodo,
        tipo_incidente,detalle_id
    )

    total_general = resultado["total_general"]

    return {
        "total_general": total_general,
        "limite": limite,
        "descripciones": [
            {
                "descripcion": row["descripcion"],
                "cantidad": row["cantidad"],
                "porcentaje": round(row["cantidad"] * 100 / total_general,2) if total_general else 0.0
            }
            for row in resultado["resultados"]
        ]
    }
    
def obtener_top_descripciones_proyectos(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_top_descripciones_proyectos(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    return {
        "total_general": resultado["total_general"],
        "combinaciones": [
            {
                "descripcion": row["descripcion"],
                "proyecto": row["proyecto"],
                "tickets": row["tickets"]
            }
            for row in resultado["resultados"]
        ]
    }
    
def obtener_top_detalles(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,
    periodo=None,tipo_incidente=None,detalle_id=None
):
    resultado = incident_consolidated_repository.obtener_top_detalles(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,
        nombre_resolutor,descripcion,periodo,
        tipo_incidente,detalle_id
    )

    return {
        "total_general": resultado["total_general"],
        "detalles": [
            {
                "detalle": row["detalle"],
                "tickets": row["tickets"]
            }
            for row in resultado["resultados"]
        ]
    }
    
    
def obtener_tickets_por_resolutor(
    db: Session,desde=None,hasta=None,prioridad=None,
    motivo_estado=None,motivo_resolucion=None,
    grupo_resolutor=None,proyecto=None,
    nombre_resolutor=None,descripcion=None,limite=5,
    periodo=None,tipo_incidente=None,detalle_id=None
):

    resultado = obtener_rendimiento_resolutores(
        db,desde,hasta,prioridad,motivo_estado,
        motivo_resolucion,grupo_resolutor,proyecto,nombre_resolutor,
        descripcion,pagina=1,
        tamano=limite,
        periodo=periodo,
        tipo_incidente=tipo_incidente,
        detalle_id=detalle_id
    )

    return {
        "total_general": resultado["total_general"],
        "limite": limite,
        "periodos": resultado["periodos"],
        "resolutores": resultado["resolutores"]
    }
