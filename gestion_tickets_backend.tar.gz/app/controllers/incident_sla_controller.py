from fastapi import (APIRouter,Depends,File,HTTPException,UploadFile,)
from sqlalchemy.orm import Session
from app.database.sqlserver import get_sqlserver_db
from app.schemas.sla_import_schema import (IncidentSLAFiltersOut, IncidentSLAInsightsOut, IncidentSLAParetoItem, IncidentSLAProyectoItem, IncidentSLAResolutorItem, IncidentSLATendenciaOut, IncidentSLATrendItem, IncidentSLAVolumenItem, SLAImportOut, IncidentSLAKPIOut)
from app.services import (incident_sla_service,)
from datetime import date
from typing import Optional
from fastapi import Query

router = APIRouter( prefix="/incident-sla",  tags=["Incident SLA"])

@router.post("/import", response_model=SLAImportOut)
def importar_incident_sla(archivo: UploadFile = File(...), db: Session = Depends(get_sqlserver_db)):
    try:
        return incident_sla_service.importar(db,archivo.file,archivo.filename)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error))
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))
    
@router.get("/filters", response_model=IncidentSLAFiltersOut)
def obtener_opciones_filtros(db: Session = Depends(get_sqlserver_db)):
    return incident_sla_service.obtener_opciones_filtros(db)
    
@router.get("/kpis",response_model=IncidentSLAKPIOut)
def obtener_kpis(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_kpis(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

@router.get("/insights",response_model=IncidentSLAInsightsOut)
def obtener_insights(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_insights(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

#SLA Solución: Tendencia
@router.get("/sla-solucion-tendencia",response_model=list[IncidentSLATrendItem])
def obtener_sla_solucion_tendencia(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_sla_solucion_tendencia(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

#Volumen de Incidentes
@router.get("/volumen-incidentes",response_model=list[IncidentSLAVolumenItem])
def obtener_volumen_incidentes(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_volumen_incidentes(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

#Explorador por Proyectos
@router.get("/proyectos",response_model=list[IncidentSLAProyectoItem])
def obtener_explorador_proyectos(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_explorador_proyectos(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

#Pareto de Tipos de Incidente
@router.get("/pareto-tipos",response_model=list[IncidentSLAParetoItem])
def obtener_pareto_tipos(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_pareto_tipos(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )


#Tendencia de Incidentes    
@router.get("/tendencia-incidentes",response_model=IncidentSLATendenciaOut)
def obtener_tendencia_incidentes(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_tendencia_incidentes(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )

#Desempeño por Resolutor
@router.get("/resolutores",response_model=list[IncidentSLAResolutorItem])
def obtener_desempeno_resolutores(
    desde: Optional[date] = None,
    hasta: Optional[date] = None,
    grupo_resolutor: Optional[str] = None,
    prioridad: Optional[str] = None,
    proyecto: Optional[str] = None,
    tipo_incidente: Optional[list[str]] = Query(default=None),
    db: Session = Depends(get_sqlserver_db)
):
    return incident_sla_service.obtener_desempeno_resolutores(
        db=db,
        desde=desde,
        hasta=hasta,
        grupo_resolutor=grupo_resolutor,
        prioridad=prioridad,
        proyecto=proyecto,
        tipo_incidente=tipo_incidente
    )
    
