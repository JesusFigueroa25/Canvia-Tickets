from datetime import date

from fastapi import (APIRouter,Depends,File,HTTPException, Query,UploadFile,)
from sqlalchemy.orm import Session
from app.database.sqlserver import get_sqlserver_db
from app.schemas.consolidated_import_schema import (ConsolidatedImportOut, RequirementConsolidatedFiltersOut, RequirementConsolidatedKPIOut, RequirementConsolidatedPrioridadItem, RequirementConsolidatedPrioridadMensualItem, RequirementConsolidatedProyectoItem, RequirementConsolidatedTipoItem, RequirementConsolidatedTopProyectosOut, RequirementConsolidatedVolumenItem,)
from app.services import (requirement_consolidated_service,)

router = APIRouter(prefix="/requirement-consolidated", tags=["Requirement Consolidated"])

@router.post("/import", response_model=ConsolidatedImportOut)
def importar_requirement_consolidated(archivo: UploadFile = File(...), db: Session = Depends(get_sqlserver_db)):
    try:
        return requirement_consolidated_service.importar(db, archivo.file, archivo.filename)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error))
    except Exception as error:
        raise HTTPException(status_code=500, detail=str(error))


@router.get("/filters",response_model=RequirementConsolidatedFiltersOut)
def obtener_opciones_filtros(db: Session = Depends(get_sqlserver_db)):
    return requirement_consolidated_service.obtener_opciones_filtros(db)    

@router.get("/kpis",response_model=RequirementConsolidatedKPIOut)
def obtener_kpis(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_kpis(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)

#Volumen Mensual de Requerimientos
@router.get("/volumen-mensual",response_model=list[RequirementConsolidatedVolumenItem])
def obtener_volumen_mensual(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_volumen_mensual(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)

#Explorador por Proyectos
@router.get("/proyectos",response_model=list[RequirementConsolidatedProyectoItem])
def obtener_proyectos(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_proyectos(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)

#Distribución por Tipo de Requerimiento
@router.get("/tipos",response_model=list[RequirementConsolidatedTipoItem])
def obtener_tipos(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
limite: int = Query(10, ge=1, le=100),
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_tipos(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto,limite)

#Distribución por Prioridad
@router.get("/prioridades",response_model=list[RequirementConsolidatedPrioridadItem])
def obtener_prioridades(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_prioridades(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)

#Top 10: Tickets por Proyecto y Mes
@router.get("/top-proyectos",response_model=RequirementConsolidatedTopProyectosOut)
def obtener_top_proyectos(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_top_proyectos(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)

#N.º de Requerimientos por Prioridad
@router.get("/prioridad-mensual",response_model=list[RequirementConsolidatedPrioridadMensualItem])
def obtener_prioridad_mensual(
desde: date | None = None, 
hasta: date | None = None, 
prioridad: str | None = None, 
motivo_estado: str | None = None, 
motivo_resolucion: str | None = None, 
grupo_resolutor: str | None = None, 
proyecto: str | None = None, 
db: Session = Depends(get_sqlserver_db)
):
    return requirement_consolidated_service.obtener_prioridad_mensual(db,desde,hasta,prioridad,motivo_estado,motivo_resolucion,grupo_resolutor,proyecto)    
